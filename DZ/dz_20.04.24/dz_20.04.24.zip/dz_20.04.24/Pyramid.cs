﻿using System;

namespace dz_20._04._24
{
    public class Pyramid : Wonder
    {
        public Pyramid() : base("Пирамида Хеопса") { }
    }
}
