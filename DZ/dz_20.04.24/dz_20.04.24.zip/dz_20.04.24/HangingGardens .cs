﻿using System;

namespace dz_20._04._24
{
    public class HangingGardens : Wonder
    {
        public HangingGardens() : base("Висячие сады Семирамиды") { }
    }
}
