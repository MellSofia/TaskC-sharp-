﻿using System;

namespace dz_20._04._24
{
    public class Colossus : Wonder
    {
        public Colossus() : base("Колосс Родосский") { }
    }
}
