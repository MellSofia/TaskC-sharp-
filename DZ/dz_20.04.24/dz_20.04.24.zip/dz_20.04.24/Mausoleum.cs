﻿using System;

namespace dz_20._04._24
{
    public class Mausoleum : Wonder
    {
        public Mausoleum() : base("Мавзолей в Галикарнасе") { }
    }
}
