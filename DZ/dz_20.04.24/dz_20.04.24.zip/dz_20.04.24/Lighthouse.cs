﻿using System;

namespace dz_20._04._24
{
    public class Lighthouse : Wonder
    {
        public Lighthouse() : base("Александрийский маяк") { }
    }
}
