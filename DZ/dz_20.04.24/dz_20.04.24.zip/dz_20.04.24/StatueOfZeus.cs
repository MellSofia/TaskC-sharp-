﻿using System;

namespace dz_20._04._24
{
    public class StatueOfZeus : Wonder
    {
        public StatueOfZeus() : base("Статуя Зевса в Олимпии") { }
    }
}
