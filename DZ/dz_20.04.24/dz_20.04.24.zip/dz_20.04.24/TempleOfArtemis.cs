﻿using System;

namespace dz_20._04._24
{
    public class TempleOfArtemis : Wonder
    {
        public TempleOfArtemis() : base("Храм Артемиды в Эфесе") { }
    }
}
