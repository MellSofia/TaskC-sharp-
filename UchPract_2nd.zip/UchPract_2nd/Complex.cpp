#include "Complex.h"

using namespace std;

void Complex::Init(int &newRe, int &newIm)
{
    Re = newRe;
    Im = newIm;
    return;
}

Complex& Complex::operator+=(Complex second_cmpl)
{
    Re += second_cmpl.Re;
    Im += second_cmpl.Im;
    return (*this);
}

Complex& Complex::operator-=(Complex second_cmpl)
{
    Re -= second_cmpl.Re;
    Im -= second_cmpl.Im;
    return (*this);
}

Complex& Complex::operator*=(Complex second_cmpl)
{
    Re = (Re * second_cmpl.Re - Im * second_cmpl.Im);
    Im = (Re * second_cmpl.Im + Im * second_cmpl.Re);
    return (*this);
}

Complex& Complex::operator/=(Complex second_cmpl)
{
    int powRe = (second_cmpl.Re * second_cmpl.Re);
    int powIm = (second_cmpl.Im * second_cmpl.Im);
    int sum = (powRe + powIm);
    if (sum == 0)
    {
        Re = 0;
        Im = 0;
    }
    else
    {
        Re = ((Re * second_cmpl.Re + Im * second_cmpl.Im) / sum);
        Im = ((Im * second_cmpl.Re - Re * second_cmpl.Im) / sum);
    }
    return (*this);
}

void Complex::TwoString(string &out_Re, string &out_Im)
{
    out_Re += to_string(Re);
    out_Im += to_string(Im);
    return;
}

string Complex::toString()
{
    string disp_string;
    disp_string.push_back('(');
    disp_string += to_string(Re);
    disp_string.push_back(' ');
    if (Im < 0)     disp_string.push_back('-');
    else            disp_string.push_back('+');
    disp_string.push_back(' ');
    disp_string += to_string(abs(Im));
    disp_string.push_back('i');
    disp_string.push_back(')');
    return disp_string;
}
