#ifndef COMPLEX_H_INCLUDED
#define COMPLEX_H_INCLUDED

#include <string>
#include <random>
#include <ctime>

class Complex
{
    private:
        int Re;
        int Im;
    public:
        void Init(int &newRe, int &newIm);
        Complex &operator+=(Complex second_cmpl);
        Complex &operator-=(Complex second_cmpl);
        Complex &operator*=(Complex second_cmpl);
        Complex &operator/=(Complex second_cmpl);
        void TwoString(std::string &out_Re, std::string &out_Im);
        std::string toString();
};

#endif // COMPLEX_H_INCLUDED
